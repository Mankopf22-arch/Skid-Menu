﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Skid_Menu
{
    public partial class Form1 : Form
    {
        private const int HOTKEY_ID = 9000;
        private const int WM_HOTKEY = 0x0312;
        private const int VK_RSHIFT = 0xA1;

        [DllImport("user32.dll")]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, int fsModifiers, int vk);

        [DllImport("user32.dll")]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        private bool _attached = false;
        private bool _internalUiEnabled = false;
        private InternalUiForm _internalUi = null;

        private Panel topPanel;
        private Panel contentPanel;

        private Button btnTabHome;
        private Button btnTabEditor;
        private Button btnTabSettings;
        private Button btnAttach;
        private Label statusLabel;

        private Panel homePage;
        private Panel editorPage;
        private Panel settingsPage;

        private RichTextBox editor;
        private RichTextBox output;
        private Button btnExecute;
        private Button btnClear;
        private Button btnOpen;
        private Button btnSave;

        private CheckBox chkAutoAttach;
        private CheckBox chkDark;
        private CheckBox chkVerbose;
        private CheckBox chkInternalUi;
        private Label lblInternalStatus;

        private Timer robloxCheckTimer;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint, true);

            Text = "Skid Menu";
            Size = new Size(850, 550);
            MinimumSize = new Size(700, 450);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.Black;
            Font = new Font("Segoe UI", 9);
            DoubleBuffered = true;

            BuildTopBar();
            BuildContent();
            BuildHomePage();
            BuildEditorPage();
            BuildSettingsPage();
            ShowHome();

            try
            {
                RegisterHotKey(this.Handle, HOTKEY_ID, 0, VK_RSHIFT);
            }
            catch
            {
                Log("Hotkey registration failed.");
            }

            robloxCheckTimer = new Timer();
            robloxCheckTimer.Interval = 2000;
            robloxCheckTimer.Tick += RobloxCheckTimer_Tick;
            robloxCheckTimer.Start();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            try
            {
                UnregisterHotKey(this.Handle, HOTKEY_ID);
            }
            catch { }

            if (_internalUi != null && !_internalUi.IsDisposed)
            {
                _internalUi.Close();
                _internalUi = null;
            }

            base.OnFormClosing(e);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_HOTKEY && m.WParam.ToInt32() == HOTKEY_ID)
            {
                ToggleInternalUi();
            }
            base.WndProc(ref m);
        }

        private void ToggleInternalUi()
        {
            if (!_attached) return;
            if (!_internalUiEnabled) return;

            if (_internalUi == null || _internalUi.IsDisposed)
            {
                _internalUi = new InternalUiForm();
                _internalUi.FormClosed += (s, e) => { _internalUi = null; };
                _internalUi.Show();
            }
            else
            {
                if (_internalUi.Visible)
                    _internalUi.Hide();
                else
                {
                    _internalUi.Show();
                    _internalUi.BringToFront();
                }
            }
        }

        private void BuildTopBar()
        {
            topPanel = new Panel();
            topPanel.Dock = DockStyle.Top;
            topPanel.Height = 50;
            topPanel.BackColor = Color.FromArgb(10, 10, 10);
            Controls.Add(topPanel);

            var logo = new Label();
            logo.Text = "\uD83D\uDC80  SKID MENU";
            logo.Font = new Font("Segoe UI", 12, FontStyle.Bold);
            logo.ForeColor = Color.FromArgb(0, 170, 255);
            logo.Location = new Point(15, 14);
            logo.AutoSize = true;
            topPanel.Controls.Add(logo);

            btnTabHome = MakeTabBtn("\uD83C\uDFE0 Home", 160);
            btnTabEditor = MakeTabBtn("\uD83D\uDCDD Editor", 255);
            btnTabSettings = MakeTabBtn("\u2699\uFE0F Settings", 350);

            btnTabHome.Click += (s, ev) => ShowHome();
            btnTabEditor.Click += (s, ev) => ShowEditor();
            btnTabSettings.Click += (s, ev) => ShowSettings();

            topPanel.Controls.Add(btnTabHome);
            topPanel.Controls.Add(btnTabEditor);
            topPanel.Controls.Add(btnTabSettings);

            btnAttach = new Button();
            btnAttach.Text = "\uD83D\uDE80 Attach";
            btnAttach.Left = 450;
            btnAttach.Top = 12;
            btnAttach.Width = 95;
            btnAttach.Height = 26;
            btnAttach.FlatStyle = FlatStyle.Flat;
            btnAttach.FlatAppearance.BorderSize = 0;
            btnAttach.ForeColor = Color.White;
            btnAttach.BackColor = Color.FromArgb(0, 120, 215);
            btnAttach.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            btnAttach.Cursor = Cursors.Hand;
            btnAttach.Click += (s, ev) => AttachToRoblox();
            topPanel.Controls.Add(btnAttach);

            statusLabel = new Label();
            statusLabel.Text = "\uD83D\uDD34 Not attached";
            statusLabel.Left = 560;
            statusLabel.Top = 18;
            statusLabel.Width = 300;
            statusLabel.ForeColor = Color.Gray;
            statusLabel.Font = new Font("Segoe UI", 9);
            statusLabel.AutoSize = true;
            topPanel.Controls.Add(statusLabel);
        }

        private Button MakeTabBtn(string text, int left)
        {
            var b = new Button();
            b.Text = text;
            b.Left = left;
            b.Top = 12;
            b.Width = 90;
            b.Height = 26;
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.ForeColor = Color.Gray;
            b.BackColor = Color.FromArgb(18, 18, 18);
            b.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            b.Cursor = Cursors.Hand;
            return b;
        }

        private void BuildContent()
        {
            contentPanel = new Panel();
            contentPanel.Dock = DockStyle.Fill;
            contentPanel.BackColor = Color.Black;
            Controls.Add(contentPanel);
            contentPanel.BringToFront();
        }

        private void BuildHomePage()
        {
            homePage = new Panel();
            homePage.Dock = DockStyle.Fill;
            homePage.BackColor = Color.Black;
            homePage.Visible = false;
            contentPanel.Controls.Add(homePage);

            var title = new Label();
            title.Text = "Welcome to Skid Menu";
            title.Font = new Font("Segoe UI", 22, FontStyle.Bold);
            title.ForeColor = Color.FromArgb(0, 170, 255);
            title.Location = new Point(30, 30);
            title.AutoSize = true;
            homePage.Controls.Add(title);

            var sub = new Label();
            sub.Text = "Last Updated: 2026-10-03\nVersion: 1.0.0";
            sub.Font = new Font("Segoe UI", 10);
            sub.ForeColor = Color.Gray;
            sub.Location = new Point(30, 80);
            sub.AutoSize = true;
            homePage.Controls.Add(sub);

            var statusBox = new Panel();
            statusBox.Location = new Point(30, 140);
            statusBox.Size = new Size(380, 110);
            statusBox.BackColor = Color.FromArgb(15, 15, 15);
            statusBox.BorderStyle = BorderStyle.FixedSingle;
            homePage.Controls.Add(statusBox);

            var sbTitle = new Label();
            sbTitle.Text = "System Status";
            sbTitle.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            sbTitle.ForeColor = Color.White;
            sbTitle.Location = new Point(12, 10);
            sbTitle.AutoSize = true;
            statusBox.Controls.Add(sbTitle);

            var sbText = new Label();
            sbText.Text = "\uD83D\uDFE2 All systems nominal\n\uD83D\uDFE2 Injector ready\n\uD83D\uDFE1 Waiting for Attach";
            sbText.Font = new Font("Segoe UI", 9);
            sbText.ForeColor = Color.LightGray;
            sbText.Location = new Point(12, 40);
            sbText.AutoSize = true;
            statusBox.Controls.Add(sbText);
        }

        private void BuildEditorPage()
        {
            editorPage = new Panel();
            editorPage.Dock = DockStyle.Fill;
            editorPage.BackColor = Color.Black;
            editorPage.Visible = false;
            contentPanel.Controls.Add(editorPage);

            editor = new RichTextBox();
            editor.Dock = DockStyle.Fill;
            editor.BackColor = Color.FromArgb(20, 20, 20);
            editor.ForeColor = Color.White;
            editor.Font = new Font("Consolas", 10);
            editor.BorderStyle = BorderStyle.None;
            editor.Text = "-- Roblox Script\nprint(\"Hello, Skid!\")\n";
            editor.AcceptsTab = true;
            editor.WordWrap = false;
            editor.ScrollBars = RichTextBoxScrollBars.Both;
            editor.DetectUrls = false;
            editorPage.Controls.Add(editor);

            var outPanel = new Panel();
            outPanel.Dock = DockStyle.Bottom;
            outPanel.Height = 130;
            outPanel.BackColor = Color.FromArgb(8, 8, 8);
            editorPage.Controls.Add(outPanel);

            var outTitle = new Label();
            outTitle.Text = "  OUTPUT";
            outTitle.Dock = DockStyle.Top;
            outTitle.Height = 22;
            outTitle.BackColor = Color.FromArgb(15, 15, 15);
            outTitle.ForeColor = Color.Gray;
            outTitle.Font = new Font("Consolas", 8, FontStyle.Bold);
            outTitle.TextAlign = ContentAlignment.MiddleLeft;
            outPanel.Controls.Add(outTitle);

            output = new RichTextBox();
            output.Dock = DockStyle.Fill;
            output.BackColor = Color.FromArgb(8, 8, 8);
            output.ForeColor = Color.Lime;
            output.Font = new Font("Consolas", 9);
            output.ReadOnly = true;
            output.BorderStyle = BorderStyle.None;
            output.DetectUrls = false;
            outPanel.Controls.Add(output);

            var toolbar = new Panel();
            toolbar.Dock = DockStyle.Top;
            toolbar.Height = 45;
            toolbar.BackColor = Color.FromArgb(15, 15, 15);
            editorPage.Controls.Add(toolbar);

            btnExecute = MakeToolBtn("\u25B6 Execute", 12, Color.FromArgb(0, 150, 0));
            btnClear = MakeToolBtn("\uD83D\uDDD1 Clear", 122, Color.FromArgb(50, 50, 50));
            btnOpen = MakeToolBtn("\uD83D\uDCC2 Open", 232, Color.FromArgb(50, 50, 50));
            btnSave = MakeToolBtn("\uD83D\uDCBE Save", 342, Color.FromArgb(50, 50, 50));

            btnExecute.Click += (s, ev) => ExecuteScript();
            btnClear.Click += (s, ev) => ClearEditor();
            btnOpen.Click += (s, ev) => OpenFile();
            btnSave.Click += (s, ev) => SaveFile();

            toolbar.Controls.Add(btnExecute);
            toolbar.Controls.Add(btnClear);
            toolbar.Controls.Add(btnOpen);
            toolbar.Controls.Add(btnSave);
        }

        private Button MakeToolBtn(string text, int left, Color backColor)
        {
            var b = new Button();
            b.Text = text;
            b.Left = left;
            b.Top = 9;
            b.Width = 100;
            b.Height = 28;
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.ForeColor = Color.White;
            b.BackColor = backColor;
            b.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            b.Cursor = Cursors.Hand;
            return b;
        }

        private void BuildSettingsPage()
        {
            settingsPage = new Panel();
            settingsPage.Dock = DockStyle.Fill;
            settingsPage.BackColor = Color.Black;
            settingsPage.Visible = false;
            contentPanel.Controls.Add(settingsPage);

            var title = new Label();
            title.Text = "\u2699\uFE0F Settings";
            title.Font = new Font("Segoe UI", 20, FontStyle.Bold);
            title.ForeColor = Color.FromArgb(0, 170, 255);
            title.Location = new Point(30, 25);
            title.AutoSize = true;
            settingsPage.Controls.Add(title);

            chkAutoAttach = MakeCheck("\uD83D\uDD04 Auto-Attach on startup", 30, 90);
            chkDark = MakeCheck("\uD83C\uDF19 Dark theme (always on)", 30, 125);
            chkDark.Checked = true;
            chkDark.Enabled = false;
            chkVerbose = MakeCheck("\uD83D\uDCE2 Verbose logging", 30, 160);
            chkVerbose.Checked = true;

            settingsPage.Controls.Add(chkAutoAttach);
            settingsPage.Controls.Add(chkDark);
            settingsPage.Controls.Add(chkVerbose);

            var sep = new Label();
            sep.Text = "Internal UI";
            sep.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            sep.ForeColor = Color.White;
            sep.Location = new Point(30, 205);
            sep.AutoSize = true;
            settingsPage.Controls.Add(sep);

            chkInternalUi = MakeCheck("\uD83D\uDDA5\uFE0F Enable Internal UI (RightShift)", 30, 235);
            chkInternalUi.Enabled = false;
            chkInternalUi.CheckedChanged += ChkInternalUi_CheckedChanged;
            settingsPage.Controls.Add(chkInternalUi);

            lblInternalStatus = new Label();
            lblInternalStatus.Text = "Status: Not attached";
            lblInternalStatus.Font = new Font("Segoe UI", 9);
            lblInternalStatus.ForeColor = Color.Gray;
            lblInternalStatus.Location = new Point(50, 265);
            lblInternalStatus.AutoSize = true;
            settingsPage.Controls.Add(lblInternalStatus);

            var reset = new Button();
            reset.Text = "\uD83D\uDD04 Reset All Settings";
            reset.Location = new Point(30, 310);
            reset.Width = 180;
            reset.Height = 34;
            reset.FlatStyle = FlatStyle.Flat;
            reset.FlatAppearance.BorderSize = 0;
            reset.ForeColor = Color.White;
            reset.BackColor = Color.FromArgb(200, 50, 50);
            reset.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            reset.Cursor = Cursors.Hand;
            reset.Click += (s, ev) =>
            {
                chkAutoAttach.Checked = false;
                chkVerbose.Checked = true;
                chkInternalUi.Checked = false;
                MessageBox.Show("Settings reset.", "Skid Menu");
            };
            settingsPage.Controls.Add(reset);
        }

        private void ChkInternalUi_CheckedChanged(object sender, EventArgs e)
        {
            _internalUiEnabled = chkInternalUi.Checked;

            if (_internalUiEnabled)
            {
                lblInternalStatus.Text = "Status: Enabled - Press RightShift in Roblox";
                lblInternalStatus.ForeColor = Color.Lime;
            }
            else
            {
                lblInternalStatus.Text = "Status: Disabled";
                lblInternalStatus.ForeColor = Color.Gray;

                if (_internalUi != null && !_internalUi.IsDisposed)
                {
                    _internalUi.Close();
                    _internalUi = null;
                }
            }
        }

        private CheckBox MakeCheck(string text, int left, int top)
        {
            var c = new CheckBox();
            c.Text = text;
            c.ForeColor = Color.LightGray;
            c.Font = new Font("Segoe UI", 10);
            c.Location = new Point(left, top);
            c.AutoSize = true;
            c.Cursor = Cursors.Hand;
            return c;
        }

        private void ShowHome()
        {
            SetActiveTab(btnTabHome);
            homePage.Visible = true;
            editorPage.Visible = false;
            settingsPage.Visible = false;
        }

        private void ShowEditor()
        {
            SetActiveTab(btnTabEditor);
            homePage.Visible = false;
            editorPage.Visible = true;
            settingsPage.Visible = false;
        }

        private void ShowSettings()
        {
            SetActiveTab(btnTabSettings);
            homePage.Visible = false;
            editorPage.Visible = false;
            settingsPage.Visible = true;
        }

        private void SetActiveTab(Button active)
        {
            var tabs = new Button[] { btnTabHome, btnTabEditor, btnTabSettings };
            foreach (var t in tabs)
            {
                t.BackColor = Color.FromArgb(18, 18, 18);
                t.ForeColor = Color.Gray;
            }
            active.BackColor = Color.FromArgb(0, 120, 215);
            active.ForeColor = Color.White;
        }

        private bool IsRobloxRunning()
        {
            foreach (var p in Process.GetProcesses())
            {
                try
                {
                    if (p.ProcessName.IndexOf("RobloxPlayerBeta", StringComparison.OrdinalIgnoreCase) >= 0
                        || p.ProcessName.IndexOf("RobloxStudioBeta", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        return true;
                    }
                }
                catch { }
            }
            return false;
        }

        private void RobloxCheckTimer_Tick(object sender, EventArgs e)
        {
            if (!_attached) return;

            if (!IsRobloxRunning())
            {
                Detach();
            }
        }

        private void Detach()
        {
            _attached = false;
            statusLabel.Text = "\uD83D\uDD34 Not attached";
            statusLabel.ForeColor = Color.Gray;
            Log("Roblox closed - detached.");

            if (_internalUi != null && !_internalUi.IsDisposed)
            {
                _internalUi.Close();
                _internalUi = null;
            }

            if (chkInternalUi != null)
            {
                chkInternalUi.Checked = false;
                chkInternalUi.Enabled = false;
            }

            if (lblInternalStatus != null)
            {
                lblInternalStatus.Text = "Status: Not attached";
                lblInternalStatus.ForeColor = Color.Gray;
            }
        }

        private void AttachToRoblox()
        {
            if (_attached)
            {
                MessageBox.Show("Already attached.", "Skid Menu");
                return;
            }

            if (!IsRobloxRunning())
            {
                MessageBox.Show(
                    "Roblox is not running.\nPlease start Roblox first, then press Attach.",
                    "Skid Menu",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            var terminal = new TerminalForm();
            terminal.Owner = this;
            terminal.Show();
        }

        public void OnAttached()
        {
            _attached = true;
            statusLabel.Text = "\uD83D\uDFE2 Attached";
            statusLabel.ForeColor = Color.Lime;
            Log("Attached successfully.");

            if (chkInternalUi != null)
                chkInternalUi.Enabled = true;

            if (lblInternalStatus != null)
            {
                lblInternalStatus.Text = "Status: Attached - Internal UI available";
                lblInternalStatus.ForeColor = Color.Lime;
            }
        }

        private void ExecuteScript()
        {
            if (!_attached)
            {
                Log("Not attached to Roblox.");
                return;
            }

            string script = editor.Text;

            if (string.IsNullOrWhiteSpace(script))
            {
                Log("Editor is empty.");
                return;
            }

            Log("Compiling script...");
            Log("Encoding Lua bytecode...");

            int lineCount = script.Split('\n').Length;
            Log("Lines: " + lineCount + " | Chars: " + script.Length);
            Log("Sending to Roblox...");

            try
            {
                Log("Script executed successfully.");
                ShowExecuteToast(script, lineCount);
            }
            catch (Exception ex)
            {
                Log("Execute error: " + ex.Message);
            }
        }

        private void ShowExecuteToast(string script, int lineCount)
        {
            string preview = script.Length > 60 ? script.Substring(0, 60) + "..." : script;
            preview = preview.Replace("\n", " ").Replace("\r", " ");

            var toast = new ExecuteToastForm(lineCount, preview);
            toast.Show();
        }

        private void ClearEditor()
        {
            editor.Clear();
            Log("Editor cleared.");
        }

        private void OpenFile()
        {
            using (var ofd = new OpenFileDialog())
            {
                ofd.Filter = "Lua Files|*.lua|Text Files|*.txt|All Files|*.*";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        editor.Text = File.ReadAllText(ofd.FileName);
                        Log("Opened: " + ofd.FileName);
                    }
                    catch (Exception ex)
                    {
                        Log("Open error: " + ex.Message);
                    }
                }
            }
        }

        private void SaveFile()
        {
            using (var sfd = new SaveFileDialog())
            {
                sfd.Filter = "Lua Files|*.lua|Text Files|*.txt|All Files|*.*";
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        File.WriteAllText(sfd.FileName, editor.Text);
                        Log("Saved: " + sfd.FileName);
                    }
                    catch (Exception ex)
                    {
                        Log("Save error: " + ex.Message);
                    }
                }
            }
        }

        private void Log(string msg)
        {
            if (output == null || output.IsDisposed) return;
            output.AppendText("[" + DateTime.Now.ToString("HH:mm:ss") + "] " + msg + "\n");
            output.SelectionStart = output.TextLength;
            output.ScrollToCaret();
        }
    }

    public class SplashForm : Form
    {
        private Timer spinTimer;
        private float angle = 0f;
        private int progress = 0;
        private Label statusText;
        private Panel spinnerPanel;
        private Panel progressBar;
        private Panel progressFill;

        public SplashForm()
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(400, 260);
            BackColor = Color.FromArgb(10, 10, 10);
            TopMost = true;
            DoubleBuffered = true;

            BuildUI();

            Load += SplashForm_Load;
        }

        private void BuildUI()
        {
            var logo = new Label();
            logo.Text = "\uD83D\uDC80  SKID MENU";
            logo.Font = new Font("Segoe UI", 22, FontStyle.Bold);
            logo.ForeColor = Color.FromArgb(0, 170, 255);
            logo.AutoSize = false;
            logo.Width = 400;
            logo.Height = 40;
            logo.TextAlign = ContentAlignment.MiddleCenter;
            logo.Location = new Point(0, 30);
            Controls.Add(logo);

            spinnerPanel = new Panel();
            spinnerPanel.Size = new Size(60, 60);
            spinnerPanel.Location = new Point(170, 90);
            spinnerPanel.BackColor = Color.Transparent;
            spinnerPanel.Paint += SpinnerPanel_Paint;
            Controls.Add(spinnerPanel);

            progressBar = new Panel();
            progressBar.Size = new Size(300, 6);
            progressBar.Location = new Point(50, 190);
            progressBar.BackColor = Color.FromArgb(30, 30, 30);
            Controls.Add(progressBar);

            progressFill = new Panel();
            progressFill.Size = new Size(0, 6);
            progressFill.Location = new Point(0, 0);
            progressFill.BackColor = Color.FromArgb(0, 170, 255);
            progressBar.Controls.Add(progressFill);

            statusText = new Label();
            statusText.Text = "Starting...";
            statusText.Font = new Font("Segoe UI", 9);
            statusText.ForeColor = Color.Gray;
            statusText.AutoSize = false;
            statusText.Width = 400;
            statusText.Height = 20;
            statusText.TextAlign = ContentAlignment.MiddleCenter;
            statusText.Location = new Point(0, 215);
            Controls.Add(statusText);

            var version = new Label();
            version.Text = "v1.0.0";
            version.Font = new Font("Segoe UI", 8);
            version.ForeColor = Color.FromArgb(60, 60, 60);
            version.AutoSize = false;
            version.Width = 400;
            version.Height = 20;
            version.TextAlign = ContentAlignment.MiddleCenter;
            version.Location = new Point(0, 235);
            Controls.Add(version);
        }

        private void SplashForm_Load(object sender, EventArgs e)
        {
            spinTimer = new Timer();
            spinTimer.Interval = 30;
            spinTimer.Tick += SpinTimer_Tick;
            spinTimer.Start();
        }

        private void SpinTimer_Tick(object sender, EventArgs e)
        {
            angle += 8f;
            if (angle >= 360f) angle -= 360f;
            spinnerPanel.Invalidate();

            progress += 2;
            if (progress > 100) progress = 100;

            int width = (int)(300f * (progress / 100f));
            progressFill.Width = width;

            if (progress >= 100)
            {
                spinTimer.Stop();
                spinTimer.Dispose();

                Timer closeTimer = new Timer();
                closeTimer.Interval = 300;
                closeTimer.Tick += (cs, ce) =>
                {
                    closeTimer.Stop();
                    closeTimer.Dispose();
                    Close();
                };
                closeTimer.Start();
                return;
            }

            if (progress < 30)
                statusText.Text = "Loading components...";
            else if (progress < 60)
                statusText.Text = "Initializing injector...";
            else if (progress < 90)
                statusText.Text = "Preparing editor...";
            else
                statusText.Text = "Ready.";
        }

        private void SpinnerPanel_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            int cx = spinnerPanel.Width / 2;
            int cy = spinnerPanel.Height / 2;
            int radius = 22;

            for (int i = 0; i < 12; i++)
            {
                float a = angle + (i * 30f);
                float rad = (float)(a * Math.PI / 180.0);
                int x = cx + (int)(Math.Cos(rad) * radius) - 3;
                int y = cy + (int)(Math.Sin(rad) * radius) - 3;

                int alpha = 40 + (i * 18);
                if (alpha > 255) alpha = 255;

                using (var brush = new SolidBrush(Color.FromArgb(alpha, 0, 170, 255)))
                {
                    e.Graphics.FillEllipse(brush, x, y, 6, 6);
                }
            }
        }
    }

    public class TerminalForm : Form
    {
        private RichTextBox console;
        private Timer countdownTimer;
        private int secondsLeft = 6;

        public TerminalForm()
        {
            Text = "Skid Menu Injector";
            Size = new Size(500, 340);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.Black;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;

            console = new RichTextBox();
            console.Dock = DockStyle.Fill;
            console.BackColor = Color.Black;
            console.ForeColor = Color.Lime;
            console.Font = new Font("Consolas", 9);
            console.ReadOnly = true;
            console.BorderStyle = BorderStyle.None;
            console.DetectUrls = false;
            Controls.Add(console);

            Load += TerminalForm_Load;
        }

        private void TerminalForm_Load(object sender, EventArgs e)
        {
            Print("Skid Menu Injector v1.0.0");
            Print("------------------------------");
            Print("");
            Print("[*] Scanning for Roblox process...");
            Print("[+] Found RobloxPlayerBeta.exe");
            Print("[*] Preparing injection...");
            Print("[*] Allocating memory in target process...");
            Print("[+] Memory allocated at 0x7FF6A4C20000");
            Print("[*] Writing payload...");
            Print("[+] Payload written (48,392 bytes)");
            Print("[*] Creating remote thread...");
            Print("[+] Thread created");
            Print("");
            Print("[*] Waiting for initialization...");
            Print("");

            countdownTimer = new Timer();
            countdownTimer.Interval = 1000;
            countdownTimer.Tick += CountdownTimer_Tick;
            countdownTimer.Start();
        }

        private void CountdownTimer_Tick(object sender, EventArgs e)
        {
            secondsLeft--;
            Print("[*] Initializing... " + secondsLeft + "s");

            if (secondsLeft <= 0)
            {
                countdownTimer.Stop();
                Print("");
                Print("==============================");
                Print("  Skid Menu Injected Successfully");
                Print("==============================");
                Print("");
                Print("[+] TP Handler loaded");
                Print("[+] RakNet Library loaded");
                Print("[+] Script executor ready");
                Print("[+] UI hooks installed");

                if (Owner is Form1 main)
                    main.OnAttached();

                Timer closeTimer = new Timer();
                closeTimer.Interval = 800;
                closeTimer.Tick += (cs, ce) =>
                {
                    closeTimer.Stop();
                    closeTimer.Dispose();
                    Close();
                    var overlay = new RobloxOverlayForm();
                    overlay.Show();
                };
                closeTimer.Start();
            }
        }

        private void Print(string text)
        {
            console.AppendText(text + "\n");
            console.SelectionStart = console.TextLength;
            console.ScrollToCaret();
        }
    }

    public class RobloxOverlayForm : Form
    {
        [DllImport("user32.dll")]
        private static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

        [StructLayout(LayoutKind.Sequential)]
        public struct RECT
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        private RichTextBox messages;
        private Timer addTimer;
        private int messageIndex = 0;

        private readonly string[] lines = new string[]
        {
            "[SKID MENU] Injected Successfully",
            "[SKID MENU] RakNet Library loaded",
            "[SKID MENU] TP Handler loaded",
            "[SKID MENU] Script executor ready",
            "[SKID MENU] Press RightShift for Internal UI"
        };

        public RobloxOverlayForm()
        {
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            TopMost = true;
            BackColor = Color.Black;
            Opacity = 0.85;
            StartPosition = FormStartPosition.Manual;

            messages = new RichTextBox();
            messages.Dock = DockStyle.Fill;
            messages.BackColor = Color.Black;
            messages.ForeColor = Color.Lime;
            messages.Font = new Font("Consolas", 10);
            messages.ReadOnly = true;
            messages.BorderStyle = BorderStyle.None;
            messages.ScrollBars = RichTextBoxScrollBars.None;
            messages.DetectUrls = false;
            Controls.Add(messages);

            Load += RobloxOverlayForm_Load;
        }

        private void RobloxOverlayForm_Load(object sender, EventArgs e)
        {
            PositionOverRoblox();

            addTimer = new Timer();
            addTimer.Interval = 400;
            addTimer.Tick += AddTimer_Tick;
            addTimer.Start();

            Timer closeTimer = new Timer();
            closeTimer.Interval = 5000;
            closeTimer.Tick += (cs, ce) =>
            {
                closeTimer.Stop();
                closeTimer.Dispose();
                Close();
            };
            closeTimer.Start();
        }

        private void PositionOverRoblox()
        {
            IntPtr hwnd = IntPtr.Zero;

            foreach (var p in Process.GetProcesses())
            {
                try
                {
                    if (p.ProcessName.IndexOf("RobloxPlayerBeta", StringComparison.OrdinalIgnoreCase) >= 0
                        && p.MainWindowHandle != IntPtr.Zero)
                    {
                        hwnd = p.MainWindowHandle;
                        break;
                    }
                }
                catch { }
            }

            if (hwnd != IntPtr.Zero)
            {
                RECT r;
                if (GetWindowRect(hwnd, out r))
                {
                    int width = r.Right - r.Left;
                    int height = 180;

                    Width = width;
                    Height = height;
                    Left = r.Left;
                    Top = r.Bottom - height;
                    return;
                }
            }

            var screen = Screen.PrimaryScreen.WorkingArea;
            Width = screen.Width;
            Height = 180;
            Left = screen.Left;
            Top = screen.Bottom - 180;
        }

        private void AddTimer_Tick(object sender, EventArgs e)
        {
            if (messageIndex >= lines.Length)
            {
                addTimer.Stop();
                return;
            }

            messages.AppendText(lines[messageIndex] + "\n");
            messages.SelectionStart = messages.TextLength;
            messages.ScrollToCaret();
            messageIndex++;
        }
    }

    public class ExecuteToastForm : Form
    {
        [DllImport("user32.dll")]
        private static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

        [StructLayout(LayoutKind.Sequential)]
        public struct RECT
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        private readonly int _lines;
        private readonly string _preview;

        public ExecuteToastForm(int lines, string preview)
        {
            _lines = lines;
            _preview = preview;

            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            TopMost = true;
            BackColor = Color.Black;
            Opacity = 0.9;
            StartPosition = FormStartPosition.Manual;
            Width = 420;
            Height = 90;

            Load += ExecuteToastForm_Load;
        }

        private void ExecuteToastForm_Load(object sender, EventArgs e)
        {
            PositionOverRoblox();

            var box = new RichTextBox();
            box.Dock = DockStyle.Fill;
            box.BackColor = Color.Black;
            box.ForeColor = Color.Lime;
            box.Font = new Font("Consolas", 9);
            box.ReadOnly = true;
            box.BorderStyle = BorderStyle.None;
            box.DetectUrls = false;
            box.ScrollBars = RichTextBoxScrollBars.None;
            Controls.Add(box);

            box.AppendText("[SKID MENU] Script Executed\n");
            box.AppendText("Lines: " + _lines + "\n");
            box.AppendText(">> " + _preview + "\n");
            box.AppendText("[OK] No errors");

            Timer closeTimer = new Timer();
            closeTimer.Interval = 3500;
            closeTimer.Tick += (cs, ce) =>
            {
                closeTimer.Stop();
                closeTimer.Dispose();
                Close();
            };
            closeTimer.Start();
        }

        private void PositionOverRoblox()
        {
            IntPtr hwnd = IntPtr.Zero;

            foreach (var p in Process.GetProcesses())
            {
                try
                {
                    if (p.ProcessName.IndexOf("RobloxPlayerBeta", StringComparison.OrdinalIgnoreCase) >= 0
                        && p.MainWindowHandle != IntPtr.Zero)
                    {
                        hwnd = p.MainWindowHandle;
                        break;
                    }
                }
                catch { }
            }

            if (hwnd != IntPtr.Zero)
            {
                RECT r;
                if (GetWindowRect(hwnd, out r))
                {
                    Left = r.Left + 20;
                    Top = r.Top + 20;
                    return;
                }
            }

            var screen = Screen.PrimaryScreen.WorkingArea;
            Left = screen.Left + 20;
            Top = screen.Top + 20;
        }
    }

    public class InternalUiForm : Form
    {
        [DllImport("user32.dll")]
        private static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

        [DllImport("user32.dll")]
        private static extern bool ReleaseCapture();

        [DllImport("user32.dll")]
        private static extern IntPtr SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        [StructLayout(LayoutKind.Sequential)]
        public struct RECT
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        private Button btnTabEditor;
        private Button btnTabSettings;
        private Panel contentPanel;
        private Panel editorPage;
        private Panel settingsPage;
        private RichTextBox editorBox;
        private RichTextBox consoleBox;
        private Button btnExecute;
        private Button btnClear;
        private CheckBox chkRakNet;
        private CheckBox chkAutoExecute;
        private Label lblConnection;

        public InternalUiForm()
        {
            FormBorderStyle = FormBorderStyle.None;
            Size = new Size(540, 440);
            BackColor = Color.FromArgb(15, 15, 15);
            TopMost = true;
            ShowInTaskbar = false;
            Opacity = 0.95;
            StartPosition = FormStartPosition.Manual;

            PositionOverRoblox();

            BuildHeader();
            BuildTabBar();
            BuildContent();
            BuildEditorTab();
            BuildSettingsTab();
            ShowEditorTab();
        }

        private void PositionOverRoblox()
        {
            IntPtr hwnd = IntPtr.Zero;

            foreach (var p in Process.GetProcesses())
            {
                try
                {
                    if (p.ProcessName.IndexOf("RobloxPlayerBeta", StringComparison.OrdinalIgnoreCase) >= 0
                        && p.MainWindowHandle != IntPtr.Zero)
                    {
                        hwnd = p.MainWindowHandle;
                        break;
                    }
                }
                catch { }
            }

            if (hwnd != IntPtr.Zero)
            {
                RECT r;
                if (GetWindowRect(hwnd, out r))
                {
                    int w = r.Right - r.Left;
                    Left = r.Left + (w / 2) - (Width / 2);
                    Top = r.Top + 80;
                    return;
                }
            }

            var screen = Screen.PrimaryScreen.WorkingArea;
            Left = screen.Left + (screen.Width / 2) - (Width / 2);
            Top = screen.Top + 100;
        }

        private void BuildHeader()
        {
            var header = new Panel();
            header.Dock = DockStyle.Top;
            header.Height = 32;
            header.BackColor = Color.FromArgb(10, 10, 10);
            header.MouseDown += Header_MouseDown;
            Controls.Add(header);

            var title = new Label();
            title.Text = "\u25BC Skid Menu Internal";
            title.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            title.ForeColor = Color.FromArgb(0, 170, 255);
            title.Location = new Point(10, 8);
            title.AutoSize = true;
            title.MouseDown += Header_MouseDown;
            header.Controls.Add(title);

            lblConnection = new Label();
            lblConnection.Text = "\u25CF Connected";
            lblConnection.Font = new Font("Segoe UI", 8, FontStyle.Bold);
            lblConnection.ForeColor = Color.Lime;
            lblConnection.AutoSize = true;
            lblConnection.Location = new Point(180, 10);
            lblConnection.MouseDown += Header_MouseDown;
            header.Controls.Add(lblConnection);

            var closeBtn = new Button();
            closeBtn.Text = "\u2715";
            closeBtn.Dock = DockStyle.Right;
            closeBtn.Width = 35;
            closeBtn.FlatStyle = FlatStyle.Flat;
            closeBtn.FlatAppearance.BorderSize = 0;
            closeBtn.ForeColor = Color.LightGray;
            closeBtn.BackColor = Color.FromArgb(10, 10, 10);
            closeBtn.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            closeBtn.Cursor = Cursors.Hand;
            closeBtn.Click += (s, e) => Hide();
            closeBtn.MouseEnter += (s, e) => closeBtn.BackColor = Color.FromArgb(180, 50, 50);
            closeBtn.MouseLeave += (s, e) => closeBtn.BackColor = Color.FromArgb(10, 10, 10);
            header.Controls.Add(closeBtn);
        }

        private void Header_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, 0xA1, 0x2, 0);
            }
        }

        private void BuildTabBar()
        {
            var tabBar = new Panel();
            tabBar.Dock = DockStyle.Top;
            tabBar.Height = 32;
            tabBar.BackColor = Color.FromArgb(18, 18, 18);
            Controls.Add(tabBar);

            btnTabEditor = new Button();
            btnTabEditor.Text = "Editor";
            btnTabEditor.Left = 5;
            btnTabEditor.Top = 4;
            btnTabEditor.Width = 80;
            btnTabEditor.Height = 24;
            btnTabEditor.FlatStyle = FlatStyle.Flat;
            btnTabEditor.FlatAppearance.BorderSize = 0;
            btnTabEditor.ForeColor = Color.White;
            btnTabEditor.BackColor = Color.FromArgb(0, 120, 215);
            btnTabEditor.Font = new Font("Segoe UI", 8, FontStyle.Bold);
            btnTabEditor.Cursor = Cursors.Hand;
            btnTabEditor.Click += (s, e) => ShowEditorTab();
            tabBar.Controls.Add(btnTabEditor);

            btnTabSettings = new Button();
            btnTabSettings.Text = "Settings";
            btnTabSettings.Left = 90;
            btnTabSettings.Top = 4;
            btnTabSettings.Width = 80;
            btnTabSettings.Height = 24;
            btnTabSettings.FlatStyle = FlatStyle.Flat;
            btnTabSettings.FlatAppearance.BorderSize = 0;
            btnTabSettings.ForeColor = Color.Gray;
            btnTabSettings.BackColor = Color.FromArgb(30, 30, 30);
            btnTabSettings.Font = new Font("Segoe UI", 8, FontStyle.Bold);
            btnTabSettings.Cursor = Cursors.Hand;
            btnTabSettings.Click += (s, e) => ShowSettingsTab();
            tabBar.Controls.Add(btnTabSettings);
        }

        private void BuildContent()
        {
            contentPanel = new Panel();
            contentPanel.Dock = DockStyle.Fill;
            contentPanel.BackColor = Color.FromArgb(15, 15, 15);
            Controls.Add(contentPanel);
            contentPanel.BringToFront();
        }

        private void BuildEditorTab()
        {
            editorPage = new Panel();
            editorPage.Dock = DockStyle.Fill;
            editorPage.BackColor = Color.FromArgb(15, 15, 15);
            editorPage.Visible = false;
            contentPanel.Controls.Add(editorPage);

            editorBox = new RichTextBox();
            editorBox.Dock = DockStyle.Fill;
            editorBox.BackColor = Color.FromArgb(20, 20, 20);
            editorBox.ForeColor = Color.White;
            editorBox.Font = new Font("Consolas", 10);
            editorBox.BorderStyle = BorderStyle.None;
            editorBox.Text = "-- Internal Script\nprint(\"Internal UI loaded\")\n";
            editorBox.AcceptsTab = true;
            editorBox.WordWrap = false;
            editorBox.ScrollBars = RichTextBoxScrollBars.Both;
            editorBox.DetectUrls = false;
            editorPage.Controls.Add(editorBox);

            var consolePanel = new Panel();
            consolePanel.Dock = DockStyle.Bottom;
            consolePanel.Height = 110;
            consolePanel.BackColor = Color.FromArgb(8, 8, 8);
            editorPage.Controls.Add(consolePanel);

            consoleBox = new RichTextBox();
            consoleBox.Dock = DockStyle.Fill;
            consoleBox.BackColor = Color.FromArgb(8, 8, 8);
            consoleBox.ForeColor = Color.Lime;
            consoleBox.Font = new Font("Consolas", 9);
            consoleBox.ReadOnly = true;
            consoleBox.BorderStyle = BorderStyle.None;
            consoleBox.DetectUrls = false;
            consoleBox.Text = "[Internal] Ready\n";
            consolePanel.Controls.Add(consoleBox);

            var toolbar = new Panel();
            toolbar.Dock = DockStyle.Top;
            toolbar.Height = 38;
            toolbar.BackColor = Color.FromArgb(20, 20, 20);
            editorPage.Controls.Add(toolbar);

            btnExecute = new Button();
            btnExecute.Text = "\u25B6 Execute";
            btnExecute.Left = 8;
            btnExecute.Top = 6;
            btnExecute.Width = 90;
            btnExecute.Height = 26;
            btnExecute.FlatStyle = FlatStyle.Flat;
            btnExecute.FlatAppearance.BorderSize = 0;
            btnExecute.ForeColor = Color.White;
            btnExecute.BackColor = Color.FromArgb(0, 150, 0);
            btnExecute.Font = new Font("Segoe UI", 8, FontStyle.Bold);
            btnExecute.Cursor = Cursors.Hand;
            btnExecute.Click += (s, e) => InternalExecute();
            toolbar.Controls.Add(btnExecute);

            btnClear = new Button();
            btnClear.Text = "\uD83D\uDDD1 Clear";
            btnClear.Left = 105;
            btnClear.Top = 6;
            btnClear.Width = 90;
            btnClear.Height = 26;
            btnClear.FlatStyle = FlatStyle.Flat;
            btnClear.FlatAppearance.BorderSize = 0;
            btnClear.ForeColor = Color.White;
            btnClear.BackColor = Color.FromArgb(50, 50, 50);
            btnClear.Font = new Font("Segoe UI", 8, FontStyle.Bold);
            btnClear.Cursor = Cursors.Hand;
            btnClear.Click += (s, e) =>
            {
                editorBox.Clear();
                InternalLog("Editor cleared.");
            };
            toolbar.Controls.Add(btnClear);
        }

        private void BuildSettingsTab()
        {
            settingsPage = new Panel();
            settingsPage.Dock = DockStyle.Fill;
            settingsPage.BackColor = Color.FromArgb(15, 15, 15);
            settingsPage.Visible = false;
            contentPanel.Controls.Add(settingsPage);

            var title = new Label();
            title.Text = "Internal Settings";
            title.Font = new Font("Segoe UI", 14, FontStyle.Bold);
            title.ForeColor = Color.FromArgb(0, 170, 255);
            title.Location = new Point(20, 20);
            title.AutoSize = true;
            settingsPage.Controls.Add(title);

            chkRakNet = new CheckBox();
            chkRakNet.Text = "\uD83D\uDCE1 Enable RakNet Library";
            chkRakNet.ForeColor = Color.LightGray;
            chkRakNet.Font = new Font("Segoe UI", 10);
            chkRakNet.Location = new Point(20, 70);
            chkRakNet.AutoSize = true;
            chkRakNet.Checked = true;
            chkRakNet.Cursor = Cursors.Hand;
            settingsPage.Controls.Add(chkRakNet);

            chkAutoExecute = new CheckBox();
            chkAutoExecute.Text = "\u26A1 Auto-Execute on injection";
            chkAutoExecute.ForeColor = Color.LightGray;
            chkAutoExecute.Font = new Font("Segoe UI", 10);
            chkAutoExecute.Location = new Point(20, 105);
            chkAutoExecute.AutoSize = true;
            chkAutoExecute.Cursor = Cursors.Hand;
            settingsPage.Controls.Add(chkAutoExecute);

            var info = new Label();
            info.Text = "RakNet Library: Loaded\nVersion: 1.0.0\nStatus: Active";
            info.Font = new Font("Consolas", 9);
            info.ForeColor = Color.Lime;
            info.Location = new Point(20, 160);
            info.AutoSize = true;
            settingsPage.Controls.Add(info);

            var hint = new Label();
            hint.Text = "Press RightShift to toggle this window";
            hint.Font = new Font("Segoe UI", 9, FontStyle.Italic);
            hint.ForeColor = Color.Gray;
            hint.Location = new Point(20, 250);
            hint.AutoSize = true;
            settingsPage.Controls.Add(hint);
        }

        private void ShowEditorTab()
        {
            editorPage.Visible = true;
            settingsPage.Visible = false;
            btnTabEditor.BackColor = Color.FromArgb(0, 120, 215);
            btnTabEditor.ForeColor = Color.White;
            btnTabSettings.BackColor = Color.FromArgb(30, 30, 30);
            btnTabSettings.ForeColor = Color.Gray;
        }

        private void ShowSettingsTab()
        {
            editorPage.Visible = false;
            settingsPage.Visible = true;
            btnTabSettings.BackColor = Color.FromArgb(0, 120, 215);
            btnTabSettings.ForeColor = Color.White;
            btnTabEditor.BackColor = Color.FromArgb(30, 30, 30);
            btnTabEditor.ForeColor = Color.Gray;
        }

        private void InternalExecute()
        {
            string script = editorBox.Text;
            if (string.IsNullOrWhiteSpace(script))
            {
                InternalLog("Script is empty.");
                return;
            }

            InternalLog("Compiling (" + script.Length + " chars)...");
            InternalLog("Sending to RakNet channel...");
            InternalLog("Executed successfully.");
        }

        private void InternalLog(string msg)
        {
            if (consoleBox == null || consoleBox.IsDisposed) return;
            consoleBox.AppendText("[Internal] " + msg + "\n");
            consoleBox.SelectionStart = consoleBox.TextLength;
            consoleBox.ScrollToCaret();
        }
    }
}